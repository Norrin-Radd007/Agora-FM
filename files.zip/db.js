/**
 * AGORA FM — API Client (db.js)
 * Talks to Flask backend instead of LocalStorage.
 * All async methods return Promises.
 */
var AgoraDB = (function () {

  async function api(method, path, body) {
    try {
      var opts = { method: method, credentials: 'same-origin', headers: { 'Content-Type': 'application/json' } };
      if (body !== undefined) opts.body = JSON.stringify(body);
      var res = await fetch(path, opts);
      return await res.json();
    } catch(e) {
      console.error('[AgoraDB]', path, e.message);
      return { ok: false, error: 'Cannot reach server. Is app.py running?' };
    }
  }

  var auth = {
    login:      function(email, password) { return api('POST', '/api/auth/login', {email, password}); },
    logout:     async function() { await api('POST', '/api/auth/logout'); window.location.href = 'index.html'; },
    getSession: function() { return api('GET', '/api/auth/session'); },
    isLoggedIn: async function() { var s = await api('GET', '/api/auth/session'); return !!(s && s.loggedIn); },
    _session:   null,
    getCachedSession: function() { return AgoraDB.auth._session || {}; }
  };

  var customers = {
    create: function(d) { return api('POST', '/api/customers/register', d); }
  };

  var suppliers = {
    create: function(d) { return api('POST', '/api/suppliers/register', d); },
    getAll: function()  { return api('GET',  '/api/suppliers'); },
    getById: function(id) { return api('GET', '/api/suppliers/' + id); }
  };

  var basket = {
    get:        function()      { return api('GET',    '/api/basket'); },
    addItem:    function(item)  { return api('POST',   '/api/basket/add', item); },
    removeItem: function(id)    { return api('DELETE', '/api/basket/item/' + id); },
    updateQty:  function(id, q) { return api('PUT',    '/api/basket/qty', {id, qty: q}); },
    clear:      function()      { return api('POST',   '/api/basket/clear'); },
    getCount:   async function() { var b = await basket.get(); return (b.items||[]).length; },
    getTotals:  async function() { var b = await basket.get(); return {subtotal:b.subtotal||0, vat:b.vat||0, commission:b.commission||0, total:b.total||0}; }
  };

  var orders = {
    create: function(d)   { return api('POST', '/api/orders', d); },
    getAll: function()    { return api('GET',  '/api/orders'); },
    getPdf: function(oid) { window.open('/api/orders/' + oid + '/pdf', '_blank'); }
  };

  var admin = {
    dump:  function() { return api('GET',  '/api/admin/dump'); },
    reset: function() { return api('POST', '/api/admin/reset'); }
  };

  // Pre-cache session on load
  api('GET', '/api/auth/session').then(function(s) {
    AgoraDB.auth._session = s;
  }).catch(function() {
    AgoraDB.auth._session = { loggedIn: false };
  });

  return { auth, customers, suppliers, basket, orders, admin,
           COMMISSION_RATE: 0.05, VAT_RATE: 0.20 };
})();
window.AgoraDB = AgoraDB;
